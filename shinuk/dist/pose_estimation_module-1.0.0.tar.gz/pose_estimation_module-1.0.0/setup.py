from setuptools import setup

setup(
    name="pose_estimation_module",
    version='1.0.0',
    description='pose_estimation_module',
    author='Shinuk',
    author_email='wook3024@gmail.com',
    url='https://lswook.tistory.com/',
    py_module=['pose_estimation_module']

)